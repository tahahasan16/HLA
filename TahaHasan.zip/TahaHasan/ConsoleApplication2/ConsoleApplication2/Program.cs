﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creating a linkedlist 
            // Using LinkedList class 
            LinkedList<String> my_list = new LinkedList<String>();

            // Adding elements in the LinkedList 
            // Using AddLast() method 
            my_list.AddLast("TAha");
            my_list.AddLast("Hasan");
            my_list.AddLast("Ali");
            my_list.AddLast("Khan");
            my_list.AddLast("Sameer");
            my_list.AddLast("Kashif");

            Console.WriteLine("Best students of the university:");

            // Accessing the elements of  
            // LinkedList Using foreach loop 
            foreach (string str in my_list)
            {
                Console.WriteLine(str);
            } 
        }
    }
}
